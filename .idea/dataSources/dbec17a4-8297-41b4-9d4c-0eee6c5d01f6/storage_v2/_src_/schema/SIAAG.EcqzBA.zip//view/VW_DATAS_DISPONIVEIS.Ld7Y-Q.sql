CREATE VIEW VW_DATAS_DISPONIVEIS AS
  SELECT
    AG.DATA,
    AGI.tipo_agendamento
  FROM siaag.tab_agenda ag
    JOIN siaag.tab_agenda_item agi ON ag.id = agi.ID_AGENDA
    JOIN SIAAG.TAB_USUARIO usu on usu.ID = ag.ID_USUARIO
    LEFT JOIN siaag.TAB_BLOQUEIO_AGENDA ba
      ON ag.data BETWEEN ba.data_inicio AND ba.data_fim AND ag.id_usuario = ba.id_usuario
         AND (agi.id_horario_inicio >= ba.id_horario_inicio AND agi.id_horario_fim <= ba.id_horario_fim)
  WHERE ba.id IS NULL AND agi.ativo = 1 AND ag.ativo = 1 AND usu.ID_PERFIL = 3 AND TO_DATE(ag.data) >= TO_DATE(sysdate) --ag.data >= (sysdate+14) TODO: Homologacao
GROUP BY ag.data, agi.tipo_agendamento
  ORDER BY ag.data
/

