CREATE VIEW VW_AGENDAS_DISPONIVEIS AS
  SELECT
    AG.ID,
    AG.DATA,
    AG.ID_USUARIO,
    AG.ATIVO,
    AGI.tipo_agendamento
  FROM siaag.tab_agenda ag
    JOIN siaag.tab_agenda_item agi ON ag.id = agi.ID_AGENDA
    LEFT JOIN siaag.TAB_BLOQUEIO_AGENDA ba
      ON ag.data BETWEEN ba.data_inicio AND ba.data_fim AND ag.id_usuario = ba.id_usuario
         AND (agi.id_horario_inicio >= ba.id_horario_inicio AND agi.id_horario_fim <= ba.id_horario_fim)
  WHERE ba.id IS NULL AND agi.ativo = 1 AND ag.ativo = 1
  ORDER BY ag.data
/

