CREATE VIEW VW_HORARIO_AGENDA AS
  SELECT
    agi.ID                AS id_agenda_item,
    AG.ID                 AS id_agenda,
    AG.DATA               AS data,
    agi.id_horario_inicio AS id_horario_inicio_agenda,
    agi.id_horario_fim    AS id_horario_fim_agenda,
    ba.id_horario_inicio  AS id_horario_inicio_bloqueio,
    ba.id_horario_fim     AS id_horario_fim_bloqueio,
    ag.id_usuario         AS id_atendente
  FROM siaag.tab_agenda ag
    JOIN siaag.tab_agenda_item agi ON ag.id = agi.ID_AGENDA
    LEFT JOIN siaag.TAB_BLOQUEIO_AGENDA ba ON ag.id_usuario = ba.id_usuario AND
                                              ag.data BETWEEN ba.data_inicio AND ba.data_fim
  WHERE agi.ativo = 1 AND ag.ativo = 1
  ORDER BY ag.data
/

